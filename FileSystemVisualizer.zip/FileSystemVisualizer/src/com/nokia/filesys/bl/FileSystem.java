package com.nokia.filesys.bl;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.nokia.filesys.constants.FileAction;
import com.nokia.filesys.constants.FileSysConstants;
import com.nokia.filesys.constants.ResourceType;
import com.nokia.filesys.domain.FileWithFolder;
import com.nokia.filesys.model.FolderStruct;

public class FileSystem {

	static FolderStruct root;
	static FolderStruct pwd;
	static FolderStruct traversalPath;
	private Scanner sc;

	public FileSystem() {
		root = new FolderStruct("root");
		pwd = root;
	}

	boolean isArgNull(String arg) {
		if ((null == arg) || (arg.isEmpty())) {
			System.err.println("Invalid arg to perform the expected operation!!");
			return true;
		}
		return false;
	}

	void createFolder(String folderName) {
		if (isArgNull(folderName)) {
			return;
		}
		FolderStruct newFolder = new FolderStruct(folderName);
		newFolder.setPrev(pwd);
		pwd.getNext().add(newFolder);
	}

	void changeFolder(String folderName) {
		if (isArgNull(folderName)) {
			return;
		}
		if (folderName.equalsIgnoreCase("/")) {
			pwd = root;
			return;
		} else if (folderName.equalsIgnoreCase("..")) {
			pwd = pwd.getPrev();
			return;
		}
		String[] folderNames = folderName.split("/");
		findFolders(root, folderNames[folderNames.length - 1]);
		if (traversalPath == null) {
			System.err.println("FOlder doesn't seem to exist to perform change directory!!");
			return;
		}
		pwd = traversalPath;
	}

	static void findFolders(FolderStruct start, String searchName) {
		traversalPath = null;
		if (start == null || searchName.isEmpty()) {
			System.err.println("Invalid folder path or name to search!!");
			return;
		}
		if (searchName.equalsIgnoreCase(start.getData().getFolderName())) {
			traversalPath = root;
			return;
		}
		findFoldersRecursive(start, searchName);
	}

	static void findFoldersRecursive(FolderStruct start, String searchName) {
		List<FolderStruct> next = start.getNext();
		if (!next.isEmpty()) {
			for (int index = 0; index < next.size(); index++) {
				if (searchName.equalsIgnoreCase(next.get(index).getData().getFolderName())) {
					traversalPath = next.get(index);
					return;
				}
				findFoldersRecursive(next.get(index), searchName);
			}
		}
	}

	void viewFolders(FolderStruct folder) {
		String appender = FileSysConstants.DISPLAY_APPENDER;
		if (folder == null) {
			System.err.println("Invalid folder to be traversed for display!!");
			return;
		}
		String files = (folder.getData().getFiles().isEmpty()) ? ""
				: String.format("\n%s%s", appender, folder.getData().getFiles());
		System.out.println(String.format("%s%s%s", appender, folder.getData().getFolderName(), files));
		viewFoldersRecursive(folder, appender);
	}

	void viewFoldersRecursive(FolderStruct folder, String appender) {
		List<FolderStruct> next = folder.getNext();
		Iterator<FolderStruct> itr = next.iterator();
		appender += appender;
		while (itr.hasNext()) {
			FolderStruct curr = itr.next();
			String files = (curr.getData().getFiles().isEmpty()) ? ""
					: String.format("\n%s%s", appender, curr.getData().getFiles());
			System.out.println(String.format("%s%s%s", appender, curr.getData().getFolderName(), files));
			viewFoldersRecursive(curr, appender);
		}
	}

	void touchFile(String fileWithPath) {
		if (fileWithPath == null || fileWithPath.isEmpty()) {
			System.err.println("Invalid file path to perform the required touch/create operation!!");
			return;
		}

		FileWithFolder fileNFolderDet = findFolderWithInFile(fileWithPath, 1);
		if (fileNFolderDet.getFolder() == null) {
			System.err.println("Folder in which file has to be created doesn't seem to exist!!");
			return;
		}

		fileNFolderDet.getFolder().getData().getFiles().add(fileNFolderDet.getFileName());
	}

	void remove(String resourceName, ResourceType rscType) {
		if (resourceName.isEmpty()) {
			System.err.println("Invalid file/directory name to perform the remove operation!!");
			return;
		}
		switch (rscType) {
		case FILE:
			String[] rscName = resourceName.split("/");
			FileWithFolder fileNFolderDet;
			if (rscName.length == 1) {
				fileNFolderDet = new FileWithFolder();
				fileNFolderDet.setFileName(resourceName);
				fileNFolderDet.setFolder(pwd);
			} else {
				fileNFolderDet = findFolderWithInFile(rscName[rscName.length-2], 1);
				if (fileNFolderDet.getFolder() == null) {
					System.err.println("Folder specified, to have containing the file, doesn't seem to exist!!");
					return;
				}
			}
			int index = fileNFolderDet.getFolder().getData().getFiles().indexOf(rscName[rscName.length-1]);
			if (index >= 0) {
				fileNFolderDet.getFolder().getData().getFiles().remove(index);
			} else {
				System.err.println("File doesn't seem to exist in the pwd, to perform removal!!");
			}

			break;
		case FOLDER:
			String[] folderName = resourceName.split("/");
			FileSystem.findFolders(root, folderName[folderName.length - 1]);
			if (traversalPath == null) {
				System.err.println("Invalid folder passed to perform remove operation!!");
				return;
			}
			List<FolderStruct> prevOfRemovalNode = traversalPath.getPrev().getNext();
			prevOfRemovalNode.remove(prevOfRemovalNode.indexOf(traversalPath));
			break;
		default:
			System.err.println("Invalid resource to perform removal operation!!");
			break;
		}

	}

	void copyOrMoveFile(String source, String destination, FileAction action) {
		if (source.isEmpty() || destination.isEmpty()) {
			System.err.println("Invalid folders to perform the required copy operation!!");
			return;
		}

		FileWithFolder sourceFolderDet = findFolderWithInFile(source, 1);
		if (sourceFolderDet.getFolder() == null) {
			System.err.println("Source folder doesn't seem to exist!!");
			return;
		}

		FileWithFolder destinationFolderDet = findFolderWithInFile(destination, 1);

		if (destinationFolderDet.getFolder() == null) {
			System.err.println("Destination folder doesn't seem to exist!!");
			return;
		}

		String sourceFileName = sourceFolderDet.getFileName();
		List<String> matchedFiles = sourceFolderDet.getFolder().getData().getFiles().stream()
				.filter(f -> f.equalsIgnoreCase(sourceFileName)).collect(Collectors.toList());
		// Assuming list will now have only one matched file, so addAll saves some list
		// empty checks..
		destinationFolderDet.getFolder().getData().getFiles().addAll(matchedFiles);

		switch (action) {

		case MOVE:
			sourceFolderDet.getFolder().getData().getFiles()
					.remove(sourceFolderDet.getFolder().getData().getFiles().indexOf(sourceFileName));
			break;
		case COPY:
			// Do nothing.
			break;
		default:
			System.err.println("Invalid file operation!!");
		}

	}

	FileWithFolder findFolderWithInFile(String fileWithPath, int indexOfResource) {
		FileWithFolder fileWithFolder = new FileWithFolder();
		if (fileWithPath.contains("/")) {
			String[] folderNames = fileWithPath.split("/");
			String folderNameContainingFile = folderNames[folderNames.length - indexOfResource];
			if (folderNameContainingFile.equalsIgnoreCase("..")) {
				try {
					folderNameContainingFile = pwd.getPrev().getData().getFolderName();
				} catch (Exception e) {
					System.err
							.println("Likely the root folder which has no previous!! recheck your source file path!!");
				}
			}
			findFolders(root, folderNameContainingFile);
			if (traversalPath == null) {
				findFolderWithInFile(fileWithPath, 2);
			}
			fileWithFolder.setFolder(traversalPath);
			fileWithFolder.setFileName(folderNames[folderNames.length - 1]);
		} else {
			fileWithFolder.setFolder(pwd);
			fileWithFolder.setFileName(fileWithPath);
		}
		return fileWithFolder;
	}

	void listFolder(String folderName) {
		if (isArgNull(folderName)) {
			return;
		}
		String[] folderNames = folderName.split("/");
		String folderNameContainingFile = folderNames[folderNames.length - 1];
		if (folderNameContainingFile.equalsIgnoreCase("..")) {
			try {
				folderNameContainingFile = pwd.getPrev().getData().getFolderName();
			} catch (Exception e) {
				System.err.println("Likely the root folder which has no previous!! recheck your source file path!!");
			}
		}
		findFolders(root, folderNameContainingFile);
		viewFolders(traversalPath);
	}

	void currentFolder() {
		FolderStruct curr = null;
		try {
			curr = (FolderStruct) pwd.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		if (curr.getData().getFolderName().equals(root.getData().getFolderName())) {
			System.out.println("/" + root.getData().getFolderName());
			return;
		}

		List<String> folderStructure = new LinkedList<String>();
		folderStructure.add(curr.getData().getFolderName());
		curr = curr.getPrev();
		while (curr != null) {
			folderStructure.add(curr.getData().getFolderName());
			curr = curr.getPrev();
		}
		Collections.reverse(folderStructure);
		folderStructure.forEach(i -> System.out.print("/" + i));
	}

	void cliDirector(FileSystem fs) {
		sc = new Scanner(System.in);
		boolean keepActive = true;
		do {
			System.out.print("$> ");
			String ip = sc.nextLine();
			String[] ipKeys = ip.split("\\s");
			if (ipKeys[0].trim().startsWith("mkdir")) {
				String folderName = (ipKeys.length > 1) ? ipKeys[1].trim() : null;
				fs.createFolder(folderName);
			} else if (ipKeys[0].trim().startsWith("cd")) {
				// if no arg passed for cd, defaulting it to root, since there is no home
				// defined..
				String cdString = (ipKeys.length > 1) ? ipKeys[1].trim() : root.getData().getFolderName();
				fs.changeFolder(cdString);
			} else if (ipKeys[0].trim().startsWith("ls")) {
				String lsString = (ipKeys.length > 1) ? ipKeys[1].trim() : root.getData().getFolderName();
				fs.listFolder(lsString);
			} else if (ipKeys[0].trim().startsWith("cp")) {
				if (ipKeys.length < 3) {
					System.err.println(
							"Invalid command to perform cp!! Try 'cp <sourceFileWithPath> <destinationFileWithPath or destinationPath>'");
					return;
				}
				fs.copyOrMoveFile(ipKeys[1].trim(), ipKeys[2].trim(), FileAction.COPY);
			} else if (ipKeys[0].trim().startsWith("mv")) {
				if (ipKeys.length < 3) {
					System.err.println(
							"Invalid command to perform mv!! Try 'mv <sourceFileWithPath> <destinationFileWithPath or destinationPath>'");
					return;
				}
				fs.copyOrMoveFile(ipKeys[1].trim(), ipKeys[2].trim(), FileAction.MOVE);
			} else if (ipKeys[0].trim().startsWith("rm")) {
				if (ipKeys.length < 2) {
					System.err.println(
							"Invalid command to perform mv!! Try 'mv <sourceFileWithPath> <destinationFileWithPath or destinationPath>'");
					return;
				}
				ResourceType resourceType;
				String resource;
				switch (ipKeys[1].trim()) {
				case "-r":
				case "-R":
					if (ipKeys.length < 3) {
						System.err.println(
								"Invalid command to perform mv -r!! Try 'mv -r <sourceFolder> <destinationFolder>'");
						return;
					}
					resourceType = ResourceType.FOLDER;
					resource = ipKeys[2].trim();
					break;
				default:
					resourceType = ResourceType.FILE;
					resource = ipKeys[1].trim();
					break;

				}
				fs.remove(resource, resourceType);
			} else if (ipKeys[0].trim().equalsIgnoreCase("pwd")) {
				fs.currentFolder();
			} else if (ipKeys[0].trim().equalsIgnoreCase("touch")) {
				String file = (ipKeys.length > 1) ? ipKeys[1].trim() : null;
				fs.touchFile(file);
			} else if (ipKeys[0].trim().equalsIgnoreCase("exit") || ipKeys[0].trim().equalsIgnoreCase("quit")) {
				System.err.println("Closing the session per your command!!");
				keepActive = false;
			} else {
				System.err.println("Invalid command to perform operations!!");
			}
		} while (keepActive);
		sc.close();
	}

	public static void main(String[] args) {
		FileSystem fs = new FileSystem();
		fs.cliDirector(fs);
	}
}
