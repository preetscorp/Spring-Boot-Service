package com.nokia.filesys.domain;

import com.nokia.filesys.model.FolderStruct;

public class FileWithFolder {
	FolderStruct folder;
	String fileName;

	public FolderStruct getFolder() {
		return folder;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFolder(FolderStruct folder) {
		this.folder = folder;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
