package com.nokia.filesys.constants;

public enum FileAction {
	COPY, MOVE;
}
