package com.nokia.filesys.constants;

public interface FileSysConstants {
	String DISPLAY_APPENDER = " - ";
}
