package com.nokia.filesys.constants;

public enum ResourceType {
	FILE, FOLDER;
}
