package com.nokia.filesys.model;

import java.util.ArrayList;
import java.util.List;

public class FolderStruct implements Cloneable {

	FolderStruct prev;
	List<FolderStruct> next;
	FolderDetails data;

	public FolderStruct(String folderName) {
		this.data = new FolderDetails(folderName);
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public FolderStruct getPrev() {
		return prev;
	}

	public List<FolderStruct> getNext() {
		if (next == null) {
			next = new ArrayList<FolderStruct>();
		}
		return next;
	}

	public FolderDetails getData() {
		return data;
	}

	public void setPrev(FolderStruct prev) {
		this.prev = prev;
	}

	public void setNext(List<FolderStruct> next) {
		this.next = next;
	}

	public void setData(FolderDetails data) {
		this.data = data;
	}

}
