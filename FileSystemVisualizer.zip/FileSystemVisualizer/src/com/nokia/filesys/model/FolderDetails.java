package com.nokia.filesys.model;

import java.util.ArrayList;
import java.util.List;

public class FolderDetails {
	List<String> files;
	String folderName;

	public FolderDetails(String folderName) {
		this.folderName = folderName;
	}

	public List<String> getFiles() {
		if (files == null) {
			files = new ArrayList<String>();
		}
		return files;
	}

	public String getFolderName() {
		return folderName;
	}

	public void setFiles(List<String> files) {
		this.files = files;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

}
